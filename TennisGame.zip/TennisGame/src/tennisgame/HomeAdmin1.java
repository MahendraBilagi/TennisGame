
package tennisgame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeAdmin1 extends Frame implements ActionListener
{
    Frame reggame;
    Button b1;
    HomeAdmin1()
    {
        reggame=new Frame("Hi");
        reggame.setSize(400, 400);
        
        
        b1=new Button("Click here");
        b1.addActionListener(this);
        
        reggame.add(b1);
        
        reggame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        System.out.println("Mahendra");
    }
    
    public static void main(String args[])
    {
        new HomeAdmin1();
    }
    
}
