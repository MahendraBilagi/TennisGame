
package tennisgame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.*;

public class RegisterPlayer extends Frame implements ActionListener
{
    Frame rplayer;
    Label l_plname;
    Label l_pcountry;
    Label result;
    TextField t_plname;
    Choice t_pcountry;   
    Button penrol;
   
    
    public void RegisterNewPlayer()
    {
        rplayer = new Frame("Register new Player");
        rplayer.setSize(500, 500);
        rplayer.setLayout(new GridLayout(6,2));
        rplayer.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
        
       l_plname = new Label("Enter Player Name :"); 
       l_pcountry = new Label("Choose Players Country :");
       result = new Label("Tournament Enrolled Successfully");
       result.setBackground(Color.green);
       result.setVisible(false);
        
       t_plname = new TextField();
      
       t_pcountry = new Choice();
       
       t_pcountry.insert("--Select--", 0);
       t_pcountry.insert("India", 1);
       t_pcountry.insert("Austrailia", 2);
       t_pcountry.insert("England", 3);
       t_pcountry.insert("USA", 4);
       t_pcountry.insert("Swizerland", 5);
       t_pcountry.insert("Pakistan", 6);
       t_pcountry.insert("Germany", 7);
       t_pcountry.insert("Canada", 8);
       t_pcountry.insert("Japan", 9);
       t_pcountry.insert("Chaina", 10);
       
       penrol = new Button("Register Player");
       penrol.addActionListener(this);
        
        rplayer.add(l_plname);
        rplayer.add(t_plname);
        rplayer.add(l_pcountry);
        rplayer.add(t_pcountry);
        rplayer.add(penrol);
        
        
        rplayer.setVisible(true);
        
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/tennis_game";
        String USER = "root";
        String PASS = "";
        
        Connection conn = null;
        Statement stmt = null;
            
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                String sql;
                sql = "INSERT INTO player_details VALUES (NULL, '"+t_plname.getText()+"', '"+t_pcountry.getSelectedItem()+"', CURRENT_TIMESTAMP, '1')";
                
                stmt = conn.createStatement();
                stmt.executeUpdate(sql);
                
               result.setVisible(true);
               new SelectPlayer(5);
               rplayer.setVisible(false);
               
            
               
               
      stmt.close();
      conn.close();
   }
            catch(SQLException se){
      //Handle errors for JDBC
                se.printStackTrace();
                } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
   finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }
   }
    }
    
    
}
