
package tennisgame;



public class TennisGame
{
    public static void main(String args[])
        {
            AdminLogin alogin = new AdminLogin();            
           
        }
}
