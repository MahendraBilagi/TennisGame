
package tennisgame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AdminLogin extends Frame implements ActionListener
{
    Frame loginframe;
    Label username;
    Label password;
    TextField text_username;
    TextField text_password;
    Button loginbutton;
    AdminLogin()
    {
         frameVisible();
    }
    
    public void frameVisible()
    {
        loginframe=new Frame("Please Login");        
        loginframe.setSize(400,400);
        loginframe.setLayout(new GridLayout(3,2));

        loginframe.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
        
        username = new Label();
        username.setAlignment(Label.LEFT);
        username.setText("Enter your username:");
        
        password = new Label();
        password.setAlignment(Label.LEFT);
        password.setText("Enter your Password");
       
        text_username = new TextField();
       
        
        text_password = new TextField();
        text_password.setEchoChar('?');
        //text_password.setBounds(60, 50, 170, 20);
        
        loginbutton = new Button("Login");
        
        loginbutton.addActionListener(this);
        
        
        
        loginframe.add(username);        
        loginframe.add(text_username);
        loginframe.add(password);
        loginframe.add(text_password);
        loginframe.add(loginbutton);
        loginframe.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {       
       String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
       String DB_URL = "jdbc:mysql://localhost/tennis_game";

       String USER = "root";
       String PASS = "";
       String email_id=null;
       String name = null;
       String login_passwd=null;
       Connection conn = null;
       Statement stmt = null;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);

                    
      
                String sql;
                sql = "SELECT * FROM admin_details";
                stmt = conn.createStatement();
      
      
                ResultSet rs = stmt.executeQuery(sql);

                while(rs.next())
                {
                    
                    email_id = rs.getString("email_id");
                    login_passwd = rs.getString("password");
                    name = rs.getString("name");
                    System.out.println("email_id: " + email_id);
                    System.out.println("password " + login_passwd);
  
                }
                
                if(text_username.getText().equals(email_id)&&text_password.getText().equals(login_passwd))
                {
                    username.setText("Successfull");
                    username.setBackground(Color.green);
                    loginframe.setVisible(false);
                    HomeAdmin admin = new HomeAdmin();
                    admin.adminFrameVisible(name);
                }
                else
                {
                    username.setText("UN Successfull");
                    username.setBackground(Color.red);
                }
     
      rs.close();
      stmt.close();
      conn.close();
   }
            catch(SQLException se){
      //Handle errors for JDBC
                se.printStackTrace();
                } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
   finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }
   }
   
}
          
        
    
    }              
    
   



    

