package tennisgame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class SelectPlayer extends Frame implements ActionListener
{
    Frame select_player;
    Label l_player1;
    Label l_player2;
    Choice c_player1;
    Choice c_player2;
    Button play_game;
    Button add_player;
    Button enter_manual;
    BouncingBalls bb;
    ResultSet rs;
    EnterPoints ep;
    int player_id;
    
    SelectPlayer(int id)
    {
        select_player = new Frame("Select players for tournament id "+id);
        select_player.setSize(500, 500);
        select_player.setLayout(new GridLayout(7,3));
        select_player.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
        
        l_player1 = new Label("Select Player1:");
        l_player2 = new Label("Select Player2:");
        
        c_player1 = new Choice();
        c_player2 = new Choice();
        getList();
        
        play_game = new Button("Play GAME");
        play_game.addActionListener(this);
        add_player = new Button("Add New Player");
        add_player.addActionListener(this);
        enter_manual = new Button("Enter Score");
        enter_manual.addActionListener(this);
        
        select_player.add(l_player1);
        select_player.add(c_player1);
        select_player.add(l_player2);
        select_player.add(c_player2);
        select_player.add(play_game);
        select_player.add(add_player);
        select_player.add(enter_manual);
        
        select_player.setVisible(true);
    }

    
    public void getList()
   {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/tennis_game";
        String USER = "root";
        String PASS = "";
        String email_id=null;
        String name = null;
        String login_passwd=null;
        
        
        Connection conn = null;
        Statement stmt = null;
            
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                String sql;
                sql = "SELECT * FROM player_details where status = 1";
                stmt = conn.createStatement();
          
                rs = stmt.executeQuery(sql);

                while(rs.next())
                {  
                    c_player1.insert(rs.getString("name"),player_id=Integer.parseInt(rs.getString("id")));
                    c_player2.insert(rs.getString("name"),player_id=Integer.parseInt(rs.getString("id")));
                }
      rs.close();
      stmt.close();
      conn.close();
   }
            catch(SQLException se){
      //Handle errors for JDBC
                se.printStackTrace();
                } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
   finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }
   }
   }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if(e.getSource()==add_player)
        {
            RegisterPlayer rp = new RegisterPlayer();
            rp.RegisterNewPlayer();
        }
        else if(e.getSource()==enter_manual)
        {
             ep = new EnterPoints();
             ep.createFrame();
        }
        else
        {
            bb = new BouncingBalls();
            bb.play();
            
        }
                
        
    }
    
    
}
