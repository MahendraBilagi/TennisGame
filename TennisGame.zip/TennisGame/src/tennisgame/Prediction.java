
package tennisgame;

import java.awt.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Prediction
{
    Frame f_result;
    Label l_p1result;
    Label l_p2result;   
    Button close;
    ResultSet rs;
    float total,win,player_id,f,c1,c2,c3;
    float temp1,temp2,temp3;
    float probability;

    Prediction(int i)
    {
        this.player_id=i;
    }

    
    public void predictResult()
    {
            this.f = this.win/this.total;
            
            this.c1 = this.temp1/this.win;
            this.c2 = this.temp2/this.win;
            this.c3 = this.temp3/this.win;
            
            this.probability = (this.c1*this.c2*this.c3)*this.f;
            
            System.out.println("probability is = "+this.probability);
            
            
    }
    public void connectDB(EnterPoints ent)
    {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/tennis_game";
        String USER = "root";
        String PASS = "";
        String email_id=null;
        String name = null;
        String login_passwd=null;
        
        
        Connection conn = null;
        Statement stmt = null;
            
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                String sql,sql2,set1,set2,set3;
                sql = "SELECT count(*) FROM match_summary_brief";
                sql2 = "SELECT count(*) FROM match_summary_brief where player_id='"+this.player_id+"'&& result = 1";
                set1 = "SELECT count(*) FROM match_summary_brief where player_id='"+this.player_id+"'&& set_15<='"+this.temp1+"'&& result = 1";
                set2 = "SELECT count(*) FROM match_summary_brief where player_id='"+this.player_id+"'&& set_30<='"+this.temp2+"'&& result = 1";
                set3 = "SELECT count(*) FROM match_summary_brief where player_id='"+this.player_id+"'&& set_40<='"+this.temp3+"'&& result = 1";
                stmt = conn.createStatement();
          
                rs = stmt.executeQuery(sql);
                while(rs.next())
                {   
                    total = rs.getInt(1);
                }
                
                rs = stmt.executeQuery(sql2);
                while(rs.next())
                {   
                    win = rs.getInt(1);
                    System.out.println("aaaaaaaaaaaa"+win);
                }
                rs = stmt.executeQuery(set1);
                while(rs.next())
                {   
                    temp1 = rs.getInt(1);
                    System.out.println("temp1 "+temp1);
                }
                rs = stmt.executeQuery(set2);
                while(rs.next())
                {   
                    temp2 = rs.getInt(1);
                    System.out.println("temp2 "+temp2);
                }
                rs = stmt.executeQuery(set3);
                while(rs.next())
                {   
                    temp3 = rs.getInt(1);
                    System.out.println("temp3 "+temp3);
                }
  
      rs.close();
      stmt.close();
      conn.close();
   }
            catch(SQLException se)
            {
                se.printStackTrace();
            } 
            catch (ClassNotFoundException ex) 
            {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            finally
        {
      
            try
            {
                if(stmt!=null)
                stmt.close();
            }catch(SQLException se2){
        }
            try
            {
                if(conn!=null)
                conn.close();
            }
            catch(SQLException se)
            {
                se.printStackTrace();
            }
        }
   }
}
