package tennisgame;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.*;

public class RegisterTournament extends Frame implements ActionListener
{

    Frame rtournament;
    Label l_name;
    Label l_sponcer;
    Label l_noplayers;
    Label result;
    TextField t_name;
    TextField t_sponcer;
    Choice s_noplayers;
    Button enrol;
    PopupMenu popup;
    
    public void regTourVisible()
    {
        rtournament = new Frame("Register new Tournament");
        rtournament.setSize(400, 400);
        rtournament.setLayout(new GridLayout(5,2));
        rtournament.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
        
       l_name = new Label("Enter Tournament Name :"); 
       l_sponcer = new Label("Enter Sponcer Name :");
       l_noplayers = new Label("Select Number of players :");
       result = new Label("Tournament Enrolled Successfully");
       result.setBackground(Color.green);
       result.setVisible(false);
        
       t_name = new TextField();
       t_sponcer = new TextField();
       
       s_noplayers = new Choice();
       
       s_noplayers.insert("Select", 0);
       s_noplayers.insert("2", 2);
       s_noplayers.insert("4", 4);
       s_noplayers.insert("8", 8);
       
       enrol = new Button("Enroll Tournament");
       enrol.addActionListener(this);
        
        rtournament.add(l_name);
        rtournament.add(t_name);
        rtournament.add(l_sponcer);
        rtournament.add(t_sponcer);
        rtournament.add(l_noplayers);
        rtournament.add(s_noplayers);
        rtournament.add(enrol);
        rtournament.add(result);
        
        rtournament.setVisible(true);
        
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/tennis_game";
        String USER = "root";
        String PASS = "";
        
        Connection conn = null;
        Statement stmt = null;
            
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                String sql;
                String val1 = t_name.getText();
                sql = "INSERT INTO tournament_details VALUES (NULL, '"+t_name.getText()+"', "+s_noplayers.getSelectedIndex()+", '"+t_sponcer.getText()+"', CURRENT_TIMESTAMP, '1')";
                
                stmt = conn.createStatement();
                stmt.executeUpdate(sql);
                
               result.setVisible(true);
               
      stmt.close();
      conn.close();
   }
            catch(SQLException se){
      //Handle errors for JDBC
                se.printStackTrace();
                } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
   finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }
   }
    }
    
}
