
package tennisgame;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.*;


public class HomeAdmin extends Frame implements ActionListener
{
   Frame adminhome;
   Label admin_name;
   Button add_new;
   Button select_player;
   Choice list_game;
   ResultSet rs;
   RegisterTournament reg;
   int tour_id;
   public void adminFrameVisible(String name)
   {
       adminhome = new Frame("Welcome "+name);
       adminhome.setSize(400, 400);
       adminhome.setLayout(new GridLayout(5,3));
       adminhome.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
       
       admin_name = new Label("Welcome "+name);
       
       add_new = new Button("Add new Tournament");
       add_new.addActionListener(this);
       select_player = new Button("Select Player");
       select_player.addActionListener(this);
       
       list_game = new Choice();
       getList();
       
       
       adminhome.add(admin_name);
       adminhome.add(add_new);
       adminhome.add(list_game);
       adminhome.add(select_player);
       
       
       adminhome.setVisible(true);
       
   }
   
   public void getList()
   {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/tennis_game";
        String USER = "root";
        String PASS = "";
        String email_id=null;
        String name = null;
        String login_passwd=null;
        
        
        Connection conn = null;
        Statement stmt = null;
            
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                String sql;
                sql = "SELECT * FROM tournament_details where status = 1";
                stmt = conn.createStatement();
          
                rs = stmt.executeQuery(sql);

                while(rs.next())
                {   
                    list_game.insert(rs.getString("Tournament_name"),tour_id=Integer.parseInt(rs.getString("id")));
                }
      rs.close();
      stmt.close();
      conn.close();
   }
            catch(SQLException se){
      //Handle errors for JDBC
                se.printStackTrace();
                } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
   finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }
   }
   }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if(e.getSource() == add_new)
        {
            reg = new RegisterTournament();
            adminhome.setVisible(false);
            reg.regTourVisible();
        }
        if(e.getSource()==select_player)
        {
            SelectPlayer sp = new SelectPlayer(tour_id); 
        }
        
    }

}
