package tennisgame;
import java.awt.event.ActionListener;
import java.sql.*;

public class DBconnectivity 
{
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost/tennis_game";

    static final String USER = "root";
    static final String PASS = "";

    Connection conn = null;
    Statement stmt = null; 

    ResultSet rs;

    DBconnectivity(String sql)
    {

        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            System.out.println("Connecting to database...");
            
        }
        catch(SQLException se)
        {
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
         {

            try
            {
                if(stmt!=null)
                stmt.close();
            }
            catch(SQLException se2)
            {

            }
            try
            {
                if(conn!=null)
                conn.close();
            }
            catch(SQLException se)
            {
                se.printStackTrace();
            }
        }
    }


     public void loginConnect()
     {        
             try
             {
                 String sql;
                 sql = "SELECT * FROM admin_details";
                 stmt = conn.createStatement();


                 rs = stmt.executeQuery(sql);

                 //STEP 5: Extract data from result set
                 while(rs.next())
                 {
                     //Retrieve by column name
                     //int id=rs.getInt("id");
                     //String name  = rs.getString("name");
                     String email_id = rs.getString("email_id");
                     // String first = rs.getString("first");
                     //Date date = rs.getDate("created_date");

                     //Display values
                     //System.out.println("ID: " + id);
                     //System.out.println(", name: " + name);
                     System.out.println(", email_id: " + email_id);
                     //System.out.println(", Created date " + date);
                 }
             }
                catch(SQLException se2)
                {

                }
        }

    //STEP 6: Clean-up environment

     public void conClose()
     {
         try
         {
             rs.close();
             stmt.close();
             conn.close();
         }
         catch(SQLException se2)
         {

         }
     }
    
}


