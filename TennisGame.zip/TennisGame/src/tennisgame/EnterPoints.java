
package tennisgame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EnterPoints extends Frame implements ActionListener
{
    Label l_Player1;
    Label l_Player2;
    Choice p1min;
    Choice p1sec;
    Choice p2min;
    Choice p2sec;
    Choice p1c3;
    Choice p2c3;
    Button update;
    Frame points;
    Label l2;
    Label p1result,p2result;
    
    public void createFrame()
    {
        points = new Frame("Enter set Timings");
        points.setSize(550,550);
        points.setLayout(new GridLayout(3,5));
        points.addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }        
        });
        
        l_Player1=new Label("Enter Player1 set15 and set30:");
        l_Player2=new Label("Enter Player1 set15 and set30:");
        p1result=new Label();
        p1result.setBackground(Color.green);
        p2result=new Label();
        p2result.setBackground(Color.green);
        p1result.setVisible(false);
        p2result.setVisible(false);
        
        p1min = new Choice();
        p1sec = new Choice();
        p2min = new Choice();
        p2sec = new Choice();
        p1c3 = new Choice();
        p2c3 = new Choice();
        
        for(int i=0;i<59;i++)
        {
            p1min.insert(Integer.toString(i), i);
            p2min.insert(Integer.toString(i), i);
            p1sec.insert(Integer.toString(i), i);
            p2sec.insert(Integer.toString(i), i);
            p1c3.insert(Integer.toString(i), i);
            p2c3.insert(Integer.toString(i), i);
        }
        
        update = new Button("Predict");
        update.addActionListener(this);
        
        points.add(l_Player1);
        points.add(p1min);
        points.add(p1sec);
        points.add(p1c3);
        points.add(l_Player2);
        points.add(p2min);
        points.add(p2sec);
        points.add(p2c3);
        points.add(update);
        points.add(p1result);
        points.add(p2result);
        
        points.setVisible(true);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        Prediction p1 = new Prediction(1);
        Prediction p2 = new Prediction(2);
        p1.temp1 = p1min.getSelectedIndex();
        p1.temp2 = p1sec.getSelectedIndex();
        p1.temp3 = p1c3.getSelectedIndex();
        
        p2.temp1 = p2min.getSelectedIndex();
        p2.temp2 = p2sec.getSelectedIndex();
        p2.temp3 = p2c3.getSelectedIndex();
        
        p1.connectDB(new EnterPoints());
        p2.connectDB(new EnterPoints());
        p1.predictResult();
        p2.predictResult();
        p1result.setText("P1 = "+p1.probability);
        p1result.setVisible(true);
        p2result.setText("P2= "+p2.probability);
        p2result.setVisible(true);
    }
}
